from distutils.core import setup

setup(
    name='pythonProject',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='',
    license='',
    author='81804',
    author_email='',
    description=''
)
