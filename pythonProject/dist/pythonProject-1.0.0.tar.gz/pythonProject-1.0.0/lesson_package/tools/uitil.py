def say_twice(word):
    return (word + 'i') * 2