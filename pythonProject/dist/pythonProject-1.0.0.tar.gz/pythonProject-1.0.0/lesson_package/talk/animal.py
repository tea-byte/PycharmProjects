from lesson_package.tools import uitil


def sing():
    return 'fdfdfdfe'


def cry():
    return uitil.say_twice('zfdfedfef')
