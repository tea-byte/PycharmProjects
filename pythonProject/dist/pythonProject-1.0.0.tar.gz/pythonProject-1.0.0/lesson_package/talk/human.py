from lesson_package.tools import uitil
def sing():
    return 'sing'
def cry():
    return uitil.say_twice('hh')

